Class Works

[CW2](https://mervetanrikulu.github.io/Odevler/Arraycw2.html)

[CW3](https://mervetanrikulu.github.io/Odevler/c4_data.html)

[CW4](https://mervetanrikulu.github.io/Odevler/CW4/index.html)

[CW5](https://mervetanrikulu.github.io/Odevler/CW5/fetchRemoteFile.html)

[CW6](https://mervetanrikulu.github.io/Odevler/timig.html)

[CW7](https://mervetanrikulu.github.io/Odevler/CW7/CW.7.html)

[CW9](https://mervetanrikulu.github.io/Odevler/CW9.html)

Homeworks

[HW1](https://mervetanrikulu.github.io/Odevler/homework.html)

[HW2](https://mervetanrikulu.github.io/Odevler/HW2/Databse.html)

[HW3](https://mervetanrikulu.github.io/Odevler/HM3/HMW3.html)

[HW4](https://mervetanrikulu.github.io/Odevler/index.html)

[Proje](https://mervetanrikulu.github.io/Odevler/Proje/HTMLPage1.html)


